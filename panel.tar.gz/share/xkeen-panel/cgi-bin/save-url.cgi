#!/opt/bin/sh

. /opt/share/xkeen-panel/cgi-bin/common.sh

read_post
page_header "Сохранение подписки"

if ! check_token; then
    echo '<div class="card"><h2 class="bad">Ошибка доступа</h2></div>'
    page_footer
    exit 1
fi

URL="$(url_decode "$(get_field url)")"

case "$URL" in
    https://*)
        if printf '%s' "$URL" | grep -q '[[:space:]]'; then
            MESSAGE="Ошибка: ссылка содержит пробелы"
            CLASS="bad"
        else
            printf '%s\n' "$URL" \
              > /opt/etc/xkeen/subscription.url

            chmod 600 /opt/etc/xkeen/subscription.url

            MESSAGE="Ссылка подписки сохранена"
            CLASS="ok"
        fi
        ;;
    *)
        MESSAGE="Ошибка: разрешены только ссылки https://"
        CLASS="bad"
        ;;
esac

cat <<HTML
<div class="card">
  <h2 class="$CLASS">$MESSAGE</h2>
  <p>Сама ссылка на странице не отображается.</p>
  <p><a href="/cgi-bin/panel.cgi">Вернуться в панель</a></p>
</div>
HTML

page_footer
