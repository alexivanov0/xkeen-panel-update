#!/opt/bin/sh

. /opt/share/xkeen-panel/cgi-bin/common.sh

TOKEN="$(cat /opt/etc/xkeen-panel/token)"

if pgrep xray >/dev/null 2>&1; then
    STATUS_CLASS="ok"
    STATUS_TEXT="Запущен"
else
    STATUS_CLASS="bad"
    STATUS_TEXT="Остановлен"
fi

SPACE="$(df -h /opt | tail -n 1)"

LTE_COUNT="$(
    grep -c '"tag": "lte-' \
        /opt/etc/xray/configs/04_outbounds.subscription.json \
        2>/dev/null || true
)"

case "$LTE_COUNT" in
    ''|*[!0-9]*) LTE_COUNT=0 ;;
esac

if [ -s /opt/etc/xkeen/subscription.url ]; then
    URL_STATUS="Настроена"
    URL_LENGTH="$(wc -c < /opt/etc/xkeen/subscription.url)"
else
    URL_STATUS="Не настроена"
    URL_LENGTH=0
fi

MODE="$(
    cat /opt/etc/xkeen/active-mode 2>/dev/null ||
    printf '%s\n' "subscription"
)"

case "$MODE" in
    fallback)
        MODE_CLASS="bad"
        MODE_TEXT="Резервный VLESS"
        ;;
    *)
        MODE_CLASS="ok"
        MODE_TEXT="Подписка"
        ;;
esac

if [ -s /opt/etc/xkeen/fallback-vless.url ]; then
    VLESS_STATUS="Настроен"
else
    VLESS_STATUS="Не настроен"
fi

PANEL_VERSION="$(cat /opt/etc/xkeen-panel/version 2>/dev/null || echo неизвестна)"
page_header "Prime Link — XKeen Panel"

cat <<HTML
<div class="card">
  <h1>XKeen Panel</h1>
  <p><strong>Prime Link</strong></p>

  <p>
    <strong>Xray:</strong>
    <span class="$STATUS_CLASS">$STATUS_TEXT</span>
  </p>

  <p>
    <strong>Активный режим:</strong>
    <span class="$MODE_CLASS">$MODE_TEXT</span>
  </p>

  <p><strong>LTE-серверов:</strong> $LTE_COUNT</p>

  <p>
    <strong>Подписка:</strong>
    $URL_STATUS, длина $URL_LENGTH байт
  </p>

  <p>
    <strong>Резервный ключ:</strong>
    $VLESS_STATUS
  </p>

  <pre>$SPACE</pre>
</div>

<div class="card">
  <h2>Управление Xray</h2>

  <form method="post" action="/cgi-bin/control.cgi">
    <input type="hidden" name="token" value="$TOKEN">

    <button class="start" name="action" value="start">
      Запустить
    </button>

    <button class="stop" name="action" value="stop">
      Остановить
    </button>

    <button class="restart" name="action" value="restart">
      Перезапустить
    </button>
  </form>
</div>

<div class="card">
  <h2>LTE-подписка</h2>

  <form method="post" action="/cgi-bin/save-url.cgi">
    <input type="hidden" name="token" value="$TOKEN">

    <p>Вставьте новую HTTPS-ссылку:</p>

    <textarea name="url"
      placeholder="https://сервер/подписка"></textarea>

    <p>
      <button class="save" type="submit">
        Сохранить ссылку
      </button>
    </p>
  </form>

  <form method="post" action="/cgi-bin/update.cgi">
    <input type="hidden" name="token" value="$TOKEN">

    <button class="update" type="submit">
      Обновить LTE-серверы
    </button>
  </form>
</div>

<div class="card">
  <h2>Резервный VLESS</h2>

  <p>
    Используйте этот ключ, если подписка временно не загружается.
  </p>

  <form method="post" action="/cgi-bin/vless.cgi">
    <input type="hidden" name="token" value="$TOKEN">

    <textarea name="vless"
      placeholder="vless://..."></textarea>

    <p>
      <button class="save" name="action" value="save">
        Сохранить резервный ключ
      </button>
    </p>

    <p>
      <button class="stop" name="action" value="fallback">
        Включить резервный VLESS
      </button>

      <button class="start" name="action" value="subscription">
        Вернуться на подписку
      </button>
    </p>
  </form>

  <p>
    Ключ после сохранения на странице не показывается.
  </p>
</div>

<div class="card">
  <h2>Обновление панели</h2>

  <p>
    <strong>Текущая версия:</strong>
    $PANEL_VERSION
  </p>

  <form method="post" action="/cgi-bin/panel-update.cgi">
    <input type="hidden" name="token" value="$TOKEN">

    <button class="update" name="action" value="check">
      Проверить обновление
    </button>

    <button class="save" name="action" value="install">
      Установить обновление
    </button>
  </form>
</div>
<div class="card">
  <p>
    <a href="/cgi-bin/direct.cgi">
      Белый список DIRECT
    </a>
  </p>

  <p>
    <a href="/cgi-bin/panel.cgi">
      Обновить страницу
    </a>
  </p>
</div>
HTML

page_footer
