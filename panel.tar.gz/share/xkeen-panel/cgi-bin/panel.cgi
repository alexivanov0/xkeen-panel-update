#!/opt/bin/sh

. /opt/share/xkeen-panel/cgi-bin/common.sh

TOKEN="$(cat /opt/etc/xkeen-panel/token)"
if pgrep xray >/dev/null 2>&1; then
    STATUS_CLASS="ok"
    STATUS_TEXT="Защита активна"
    STATUS_SHORT="Работает"
else
    STATUS_CLASS="bad"
    STATUS_TEXT="Защита отключена"
    STATUS_SHORT="Остановлен"
fi

KEENETIC_VERSION="$(curl -fsS --connect-timeout 2 --max-time 4 http://localhost:79/rci/show/version 2>/dev/null | jq -r '.release // .version // empty' 2>/dev/null || true)"
[ -n "$KEENETIC_VERSION" ] || KEENETIC_VERSION="не определена"
PROBE_SECONDS="$(cat /opt/etc/xkeen/probe-interval-seconds 2>/dev/null || echo 20)"
FAIL_LIMIT="$(cat /opt/etc/xkeen/watchdog-fail-limit 2>/dev/null || echo 2)"
LAST_WATCHDOG="$(tail -n 1 /opt/var/log/xkeen-watchdog.log 2>/dev/null || echo 'Событий пока нет')"
LTE_COUNT="$(grep -c '"tag": "lte-' /opt/etc/xray/configs/04_outbounds.subscription.json 2>/dev/null || true)"
case "$LTE_COUNT" in ''|*[!0-9]*) LTE_COUNT=0 ;; esac

if [ -s /opt/etc/xkeen/subscription.url ]; then
    URL_STATUS="Подключена"
    URL_CLASS="ok"
else
    URL_STATUS="Не настроена"
    URL_CLASS="bad"
fi

MODE="$(cat /opt/etc/xkeen/active-mode 2>/dev/null || printf '%s\n' subscription)"
case "$MODE" in
    fallback) MODE_CLASS="amber"; MODE_TEXT="Резервный VLESS" ;;
    *) MODE_CLASS="ok"; MODE_TEXT="Подписка" ;;
esac

if [ -s /opt/etc/xkeen/fallback-vless.url ]; then VLESS_STATUS="Настроен"; else VLESS_STATUS="Не настроен"; fi
PANEL_VERSION="$(cat /opt/etc/xkeen-panel/version 2>/dev/null || echo неизвестна)"
SPACE="$(df -h /opt | awk 'NR==2 {print $4 " свободно из " $2}')"

page_header "Prime Link — управление подключением"

cat <<HTML
<header class="topbar">
  <div class="brand"><div class="brand-mark">P</div><div><div class="brand-name">PRIME LINK</div><div class="brand-sub">Управление защищённым подключением</div></div></div>
  <div class="status-pill $STATUS_CLASS"><span class="dot"></span>$STATUS_TEXT</div>
</header>

<nav class="nav"><a href="#overview">Обзор</a><a href="#connection">Подключение</a><a href="#subscription">Подписка</a><a href="#system">Система</a><a href="/cgi-bin/direct.cgi">DIRECT</a></nav>

<section class="hero" id="overview">
  <div class="eyebrow">Prime Link · Intelligent routing</div>
  <h1>Интернет под контролем</h1>
  <p>Роутер автоматически проверяет доступные узлы и выбирает лучшее рабочее соединение. Все изменения применяются ко всей домашней сети.</p>
  <div class="hero-actions">
    <form method="post" action="/cgi-bin/control.cgi"><input type="hidden" name="token" value="$TOKEN"><button class="restart" name="action" value="restart">Перезапустить защиту</button></form>
    <form method="post" action="/cgi-bin/update.cgi"><input type="hidden" name="token" value="$TOKEN"><button class="ghost" type="submit">Проверить серверы</button></form>
  </div>
</section>

<div class="grid">
  <article class="card metric"><div class="metric-label">Состояние Xray</div><div class="metric-value $STATUS_CLASS">$STATUS_SHORT</div><div class="metric-note">Трафик домашней сети</div></article>
  <article class="card metric"><div class="metric-label">Активный режим</div><div class="metric-value $MODE_CLASS">$MODE_TEXT</div><div class="metric-note">Автоматический выбор</div></article>
  <article class="card metric"><div class="metric-label">Серверов в пуле</div><div class="metric-value">$LTE_COUNT</div><div class="metric-note">Проверяются параллельно</div></article>
  <article class="card metric"><div class="metric-label">Интервал проверки</div><div class="metric-value">$PROBE_SECONDS сек.</div><div class="metric-note">Переключение без ручных действий</div></article>
</div>

<div class="section-title" id="connection"><h2>Подключение</h2><p>Текущее состояние и аварийное восстановление</p></div>
<div class="grid">
  <section class="card wide">
    <h2>Управление защитой</h2>
    <p>Перезапуск безопасно перечитает текущую конфигурацию. Остановка временно отключит Xray.</p>
    <form class="actions" method="post" action="/cgi-bin/control.cgi"><input type="hidden" name="token" value="$TOKEN"><button class="start" name="action" value="start">Запустить</button><button class="restart" name="action" value="restart">Перезапустить</button><button class="stop" name="action" value="stop">Остановить</button></form>
  </section>
  <aside class="card side">
    <h2>Автовосстановление</h2>
    <div class="row"><span class="row-label">Проверка узлов</span><span class="row-value">каждые $PROBE_SECONDS сек.</span></div>
    <div class="row"><span class="row-label">Порог полного отказа</span><span class="row-value">$FAIL_LIMIT проверки</span></div>
    <div class="row"><span class="row-label">Последнее событие</span><span class="row-value" style="font-size:12px">$LAST_WATCHDOG</span></div>
  </aside>
</div>

<div class="section-title" id="subscription"><h2>Подписка</h2><p>На роутере хранится одна индивидуальная ссылка</p></div>
<div class="grid">
  <section class="card wide">
    <h2>Основная подписка <span class="$URL_CLASS" style="font-size:13px">· $URL_STATUS</span></h2>
    <p>Вставьте новую HTTPS-ссылку. Существующая ссылка не показывается в интерфейсе.</p>
    <form method="post" action="/cgi-bin/save-url.cgi"><input type="hidden" name="token" value="$TOKEN"><textarea name="url" placeholder="https://сервер/индивидуальная-подписка"></textarea><div class="actions"><button class="save" type="submit">Сохранить ссылку</button></div></form>
    <form method="post" action="/cgi-bin/update.cgi"><input type="hidden" name="token" value="$TOKEN"><button class="ghost" type="submit">Загрузить серверы сейчас</button></form>
  </section>
  <aside class="card side">
    <h2>Резервный ключ</h2>
    <div class="row"><span class="row-label">Состояние</span><span class="row-value">$VLESS_STATUS</span></div>
    <p class="hint">Используется только при полном отказе основного пула.</p>
    <form method="post" action="/cgi-bin/vless.cgi"><input type="hidden" name="token" value="$TOKEN"><textarea name="vless" placeholder="vless://..."></textarea><div class="actions"><button class="save" name="action" value="save">Сохранить</button><button class="stop" name="action" value="fallback">Включить резерв</button><button class="start" name="action" value="subscription">Вернуть подписку</button></div></form>
  </aside>
</div>

<div class="section-title" id="system"><h2>Система</h2><p>Версии и обслуживание панели</p></div>
<div class="grid">
  <section class="card wide">
    <h2>Обновление Prime Link</h2>
    <div class="row"><span class="row-label">Версия панели</span><span class="row-value">$PANEL_VERSION</span></div>
    <div class="row"><span class="row-label">KeeneticOS</span><span class="row-value">$KEENETIC_VERSION</span></div>
    <div class="row"><span class="row-label">Хранилище /opt</span><span class="row-value">$SPACE</span></div>
    <form class="actions" method="post" action="/cgi-bin/panel-update.cgi"><input type="hidden" name="token" value="$TOKEN"><button class="ghost" name="action" value="check">Проверить обновление</button><button class="update" name="action" value="install">Установить обновление</button></form>
  </section>
  <aside class="card side"><h2>Маршрутизация</h2><p>Добавляйте сайты и IP-адреса, которые должны открываться напрямую, без защищённого канала.</p><a class="button ghost" href="/cgi-bin/direct.cgi">Открыть список DIRECT</a></aside>
</div>

<div class="footer">Prime Link · панель $PANEL_VERSION · <a href="/cgi-bin/panel.cgi">Обновить страницу</a></div>
HTML

page_footer
