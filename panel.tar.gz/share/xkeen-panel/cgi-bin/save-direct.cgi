#!/opt/bin/sh

. /opt/share/xkeen-panel/cgi-bin/common.sh

DOMAINS_FILE="/opt/etc/xkeen/direct-domains.lst"
IPS_FILE="/opt/etc/xkeen/direct-ips.lst"
WORK="/tmp/xkeen-panel-direct.$$"

cleanup() {
    rm -rf "$WORK"
}
trap cleanup EXIT INT TERM

read_post
page_header "Применение DIRECT"

if ! check_token; then
    echo '<div class="card"><h2 class="bad">Ошибка доступа</h2></div>'
    page_footer
    exit 1
fi

mkdir -p "$WORK"

cp "$DOMAINS_FILE" "$WORK/domains.old" 2>/dev/null ||
    : > "$WORK/domains.old"

cp "$IPS_FILE" "$WORK/ips.old" 2>/dev/null ||
    : > "$WORK/ips.old"

DOMAINS="$(url_decode "$(get_field domains)")"
IPS="$(url_decode "$(get_field ips)")"

printf '%s\n' "$DOMAINS" |
    tr -d '\r' > "$DOMAINS_FILE"

printf '%s\n' "$IPS" |
    tr -d '\r' > "$IPS_FILE"

chmod 600 "$DOMAINS_FILE" "$IPS_FILE"

if RESULT="$(/opt/sbin/xkeen-direct-apply 2>&1)"; then
    CLASS="ok"
    TITLE="Белый список применён"
else
    CODE=$?

    cp "$WORK/domains.old" "$DOMAINS_FILE"
    cp "$WORK/ips.old" "$IPS_FILE"
    chmod 600 "$DOMAINS_FILE" "$IPS_FILE"

    /opt/sbin/xkeen-direct-apply >/dev/null 2>&1 || true

    RESULT="Новые правила отклонены.

Старые списки восстановлены.

Ошибка применения, код $CODE:

$RESULT"

    CLASS="bad"
    TITLE="Ошибка белого списка"
fi

SAFE_RESULT="$(
    printf '%s\n' "$RESULT" |
        html_escape
)"

cat <<HTML
<div class="card">
  <h2 class="$CLASS">$TITLE</h2>
  <pre>$SAFE_RESULT</pre>
  <p><a href="/cgi-bin/direct.cgi">Вернуться к спискам</a></p>
  <p><a href="/cgi-bin/panel.cgi">Вернуться в панель</a></p>
</div>
HTML

page_footer
