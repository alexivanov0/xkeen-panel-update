#!/opt/bin/sh
. /opt/share/xkeen-panel/cgi-bin/common.sh

read_post
page_header "Обновление панели"

if ! check_token; then
    cat <<HTML
<div class="card">
  <h2 class="bad">Доступ запрещён</h2>
  <p>Неверный защитный токен.</p>
  <p><a href="/cgi-bin/panel.cgi">Вернуться в панель</a></p>
</div>
HTML
    page_footer
    exit 1
fi

ACTION="$(url_decode "$(get_field action)")"

case "$ACTION" in
    check|install) ;;
    *)
        ACTION="check"
        ;;
esac

RESULT="$(/opt/sbin/xkeen-panel-update "$ACTION" 2>&1)"
STATUS=$?

if [ "$STATUS" -eq 0 ]; then
    CLASS="ok"
    TITLE="Операция выполнена"
else
    CLASS="bad"
    TITLE="Операция не выполнена"
fi

SAFE_RESULT="$(printf '%s\n' "$RESULT" | html_escape)"

cat <<HTML
<div class="card">
  <h2 class="$CLASS">$TITLE</h2>
  <pre>$SAFE_RESULT</pre>
  <p><a href="/cgi-bin/panel.cgi">Вернуться в панель</a></p>
</div>
HTML

page_footer
exit "$STATUS"
