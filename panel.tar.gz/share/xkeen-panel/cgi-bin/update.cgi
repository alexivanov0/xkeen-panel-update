#!/opt/bin/sh

. /opt/share/xkeen-panel/cgi-bin/common.sh

read_post
page_header "Обновление подписки"

if ! check_token; then
    echo '<div class="card"><h2 class="bad">Ошибка доступа</h2></div>'
    page_footer
    exit 1
fi

RESULT="$(/opt/sbin/xkeen-sub-update 2>&1)"
CODE=$?

SAFE_RESULT="$(printf '%s\n' "$RESULT" | html_escape)"

if [ "$CODE" -eq 0 ]; then
    TITLE_CLASS="ok"
    TITLE_TEXT="Обновление завершено"
else
    TITLE_CLASS="bad"
    TITLE_TEXT="Ошибка обновления"
fi

cat <<HTML
<div class="card">
  <h2 class="$TITLE_CLASS">$TITLE_TEXT</h2>
  <pre>$SAFE_RESULT</pre>
  <p><a href="/cgi-bin/panel.cgi">Вернуться в панель</a></p>
</div>
HTML

page_footer
