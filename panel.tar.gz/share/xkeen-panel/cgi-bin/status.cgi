#!/opt/bin/sh

printf 'Content-Type: text/html; charset=utf-8\r\n'
printf 'Cache-Control: no-store\r\n'
printf '\r\n'

if pgrep xray >/dev/null 2>&1; then
    XRAY_STATUS='Запущен'
else
    XRAY_STATUS='Остановлен'
fi

SPACE="$(df -h /opt | tail -n 1)"
XRAY_VERSION="$(/opt/sbin/xray version 2>/dev/null | head -n 1)"

cat <<HTML
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Состояние XKeen</title>
  <style>
    body {
      max-width: 760px;
      margin: 40px auto;
      padding: 0 16px;
      font-family: Arial, sans-serif;
      background: #f3f5f7;
    }
    .card {
      background: white;
      padding: 24px;
      border-radius: 14px;
      box-shadow: 0 3px 18px rgba(0,0,0,.08);
    }
    pre {
      overflow-x: auto;
      background: #eef1f4;
      padding: 12px;
      border-radius: 8px;
    }
    a {
      color: #1769e0;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>Состояние XKeen</h1>
    <p><strong>Xray:</strong> $XRAY_STATUS</p>
    <p><strong>Версия:</strong> $XRAY_VERSION</p>
    <p><strong>Память:</strong></p>
    <pre>$SPACE</pre>
    <p><a href="/">Вернуться</a></p>
  </div>
</body>
</html>
HTML
