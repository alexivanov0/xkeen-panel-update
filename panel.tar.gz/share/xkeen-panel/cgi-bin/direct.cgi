#!/opt/bin/sh

. /opt/share/xkeen-panel/cgi-bin/common.sh

DOMAINS_FILE="/opt/etc/xkeen/direct-domains.lst"
IPS_FILE="/opt/etc/xkeen/direct-ips.lst"

TOKEN="$(cat "$TOKEN_FILE" 2>/dev/null)"

DOMAINS="$(
    cat "$DOMAINS_FILE" 2>/dev/null |
        html_escape
)"

IPS="$(
    cat "$IPS_FILE" 2>/dev/null |
        html_escape
)"

DOMAIN_COUNT="$(
    sed 's/^[[:space:]]*//;s/[[:space:]]*$//' "$DOMAINS_FILE" 2>/dev/null |
        grep -v '^#' |
        grep -c '[^[:space:]]' || true
)"

IP_COUNT="$(
    sed 's/^[[:space:]]*//;s/[[:space:]]*$//' "$IPS_FILE" 2>/dev/null |
        grep -v '^#' |
        grep -c '[^[:space:]]' || true
)"

page_header "Белый список DIRECT"

cat <<HTML
<div class="card">
  <h1>Белый список DIRECT</h1>

  <p>
    Указанные домены и IP будут идти напрямую через провайдера,
    минуя VPN.
  </p>

  <p>
    <strong>Доменов:</strong> $DOMAIN_COUNT<br>
    <strong>IP и подсетей:</strong> $IP_COUNT
  </p>
</div>

<div class="card">
  <form method="post" action="/cgi-bin/save-direct.cgi">
    <input type="hidden" name="token" value="$TOKEN">

    <h2>Домены напрямую</h2>

    <p>
      Один домен на строку, без <code>https://</code> и путей.
      Обычная запись охватывает домен и его поддомены.
    </p>

    <textarea name="domains"
      style="min-height:220px"
      placeholder="gosuslugi.ru
nalog.gov.ru
example.ru">$DOMAINS</textarea>

    <h2>IP и подсети напрямую</h2>

    <p>Один IP-адрес или диапазон CIDR на строку.</p>

    <textarea name="ips"
      style="min-height:160px"
      placeholder="203.0.113.10
198.51.100.0/24">$IPS</textarea>

    <p>
      <button class="save" type="submit">
        Сохранить и применить
      </button>
    </p>
  </form>
</div>

<div class="card">
  <p><a href="/cgi-bin/panel.cgi">Вернуться в панель</a></p>
</div>
HTML

page_footer
