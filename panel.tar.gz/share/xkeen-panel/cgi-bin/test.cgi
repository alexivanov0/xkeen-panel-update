#!/opt/bin/sh
printf 'Content-Type: text/plain\r\n'
printf '\r\n'
printf 'CGI WORKS\n'
