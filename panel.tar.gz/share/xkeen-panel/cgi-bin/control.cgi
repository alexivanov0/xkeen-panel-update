#!/opt/bin/sh

. /opt/share/xkeen-panel/cgi-bin/common.sh

read_post
page_header "Управление XKeen"

if ! check_token; then
    echo '<div class="card"><h2 class="bad">Ошибка доступа</h2></div>'
    page_footer
    exit 1
fi

ACTION="$(url_decode "$(get_field action)")"

case "$ACTION" in
    start)
        RESULT="$(xkeen -start 2>&1)"
        ;;
    stop)
        RESULT="$(xkeen -stop 2>&1)"
        ;;
    restart)
        RESULT="$(xkeen -restart 2>&1)"
        ;;
    *)
        RESULT="Неизвестная команда"
        ;;
esac

SAFE_RESULT="$(printf '%s\n' "$RESULT" | html_escape)"

cat <<HTML
<div class="card">
  <h2>Результат</h2>
  <pre>$SAFE_RESULT</pre>
  <p><a href="/cgi-bin/panel.cgi">Вернуться в панель</a></p>
</div>
HTML

page_footer
