#!/opt/bin/sh

. /opt/share/xkeen-panel/cgi-bin/common.sh

read_post
page_header "Резервный VLESS"

if ! check_token; then
    echo '<div class="card"><h2 class="bad">Ошибка доступа</h2></div>'
    page_footer
    exit 1
fi

ACTION="$(url_decode "$(get_field action)")"
KEY="$(url_decode "$(get_field vless)")"

case "$ACTION" in
    save)
        RESULT="$(/opt/sbin/xkeen-vless-mode save "$KEY" 2>&1)"
        CODE=$?
        ;;
    fallback)
        RESULT="$(/opt/sbin/xkeen-vless-mode fallback 2>&1)"
        CODE=$?
        ;;
    subscription)
        RESULT="$(/opt/sbin/xkeen-vless-mode subscription 2>&1)"
        CODE=$?
        ;;
    *)
        RESULT="Ошибка: неизвестное действие"
        CODE=1
        ;;
esac

SAFE_RESULT="$(printf '%s\n' "$RESULT" | html_escape)"

if [ "$CODE" -eq 0 ]; then
    TITLE_CLASS="ok"
    TITLE_TEXT="Операция выполнена"
else
    TITLE_CLASS="bad"
    TITLE_TEXT="Операция не выполнена"
fi

cat <<HTML
<div class="card">
  <h2 class="$TITLE_CLASS">$TITLE_TEXT</h2>
  <pre>$SAFE_RESULT</pre>
  <p>Резервный ключ на странице не отображается.</p>
  <p><a href="/cgi-bin/panel.cgi">Вернуться в панель</a></p>
</div>
HTML

page_footer
