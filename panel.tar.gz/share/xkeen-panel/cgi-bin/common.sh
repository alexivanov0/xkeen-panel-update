#!/opt/bin/sh
PATH=/opt/sbin:/opt/bin:/opt/usr/sbin:/opt/usr/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH

TOKEN_FILE="/opt/etc/xkeen-panel/token"

html_escape() {
    sed \
      -e 's/&/\&amp;/g' \
      -e 's/</\&lt;/g' \
      -e 's/>/\&gt;/g' \
      -e 's/"/\&quot;/g'
}

url_decode() {
    VALUE="$(printf '%s' "$1" | sed 's/+/ /g; s/%/\\x/g')"
    printf '%b' "$VALUE"
}

get_field() {
    FIELD="$1"

    printf '%s' "$POST_DATA" |
    tr '&' '\n' |
    sed -n "s/^${FIELD}=//p" |
    head -n 1
}

read_post() {
    case "${CONTENT_LENGTH:-0}" in
        ''|*[!0-9]*) CONTENT_LENGTH=0 ;;
    esac

    POST_DATA="$(dd bs=1 count="$CONTENT_LENGTH" 2>/dev/null)"
}

check_token() {
    RECEIVED="$(url_decode "$(get_field token)")"
    EXPECTED="$(cat "$TOKEN_FILE" 2>/dev/null)"

    [ -n "$EXPECTED" ] && [ "$RECEIVED" = "$EXPECTED" ]
}

page_header() {
    TITLE="$1"

    printf 'Content-Type: text/html; charset=utf-8\r\n'
    printf 'Cache-Control: no-store\r\n'
    printf '\r\n'

    cat <<HTML
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>$TITLE</title>
<style>
:root{color-scheme:dark;--bg:#07101f;--panel:#101c30;--panel2:#13233b;--line:#233653;--text:#f4f7fb;--muted:#8fa3bd;--brand:#6d7cff;--cyan:#38c7ff;--green:#42d392;--red:#ff6577;--amber:#ffc857}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{max-width:1120px;margin:0 auto;padding:28px 20px 54px;font-family:Inter,system-ui,-apple-system,"Segoe UI",Arial,sans-serif;background:radial-gradient(circle at 85% -10%,#193873 0,transparent 34%),radial-gradient(circle at -10% 35%,#17274a 0,transparent 27%),var(--bg);color:var(--text);line-height:1.5;min-height:100vh}
a{color:#91a8ff;text-decoration:none}a:hover{color:#c2ceff}.topbar{display:flex;align-items:center;justify-content:space-between;gap:20px;margin-bottom:28px}.brand{display:flex;align-items:center;gap:12px}.brand-mark{width:42px;height:42px;border-radius:13px;background:linear-gradient(145deg,var(--cyan),var(--brand));display:grid;place-items:center;font-weight:900;box-shadow:0 10px 28px #536dff55}.brand-name{font-size:20px;font-weight:800;letter-spacing:.08em}.brand-sub{font-size:12px;color:var(--muted)}.status-pill{display:inline-flex;align-items:center;gap:8px;padding:9px 13px;border:1px solid #2a654f;border-radius:999px;background:#11352b;color:#80efbc;font-size:13px;font-weight:700}.status-pill.bad{border-color:#703746;background:#3a1e29;color:#ff9aaa}.dot{width:8px;height:8px;border-radius:50%;background:currentColor;box-shadow:0 0 12px currentColor}
.hero{position:relative;overflow:hidden;padding:30px;border:1px solid #294063;border-radius:24px;background:linear-gradient(135deg,#152947 0%,#111e34 58%,#182449 100%);box-shadow:0 22px 70px #0007;margin-bottom:18px}.hero:after{content:"";position:absolute;width:260px;height:260px;border-radius:50%;right:-90px;top:-120px;background:#5974ff33;filter:blur(3px)}.eyebrow{color:#7edcff;text-transform:uppercase;letter-spacing:.14em;font-size:12px;font-weight:800}.hero h1{font-size:clamp(28px,5vw,48px);line-height:1.08;margin:8px 0 10px;letter-spacing:-.035em}.hero p{margin:0;color:#afbdd0;max-width:650px}.hero-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:22px}
.grid{display:grid;grid-template-columns:repeat(12,1fr);gap:16px;margin:16px 0}.card{grid-column:span 12;background:linear-gradient(180deg,#111f34,#0e192b);padding:22px;border:1px solid var(--line);border-radius:19px;box-shadow:0 12px 36px #0003}.card h2{margin:0 0 5px;font-size:19px}.card p{color:#b4c0d1}.metric{grid-column:span 3;min-height:138px}.metric-label{font-size:13px;color:var(--muted)}.metric-value{font-size:29px;font-weight:800;letter-spacing:-.03em;margin-top:14px}.metric-note{color:var(--muted);font-size:12px;margin-top:4px}.wide{grid-column:span 7}.side{grid-column:span 5}.section-title{margin:30px 2px 12px}.section-title h2{margin:0;font-size:22px}.section-title p{margin:3px 0;color:var(--muted);font-size:14px}.row{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:13px 0;border-bottom:1px solid #20314b}.row:last-child{border-bottom:0}.row-label{color:var(--muted);font-size:13px}.row-value{text-align:right;font-weight:650}.ok{color:var(--green);font-weight:750}.bad{color:var(--red);font-weight:750}.amber{color:var(--amber);font-weight:750}
button,.button{appearance:none;border:1px solid transparent;border-radius:11px;padding:11px 15px;margin:4px 4px 4px 0;font:inherit;font-size:14px;font-weight:750;cursor:pointer;transition:.18s ease}.start,.save,.update,.restart{background:linear-gradient(135deg,#6278ff,#795cff);color:white;box-shadow:0 7px 18px #536dff33}.start:hover,.save:hover,.update:hover,.restart:hover{transform:translateY(-1px);filter:brightness(1.08)}.stop{background:#2b1d2a;border-color:#583141;color:#ff96a5}.ghost{background:#15253d;border-color:#2b4262;color:#dce7f7}.button{display:inline-block}
textarea,input[type=text],input[type=url],input:not([type]){width:100%;min-height:48px;padding:13px 14px;border:1px solid #2b4262;border-radius:12px;background:#091525;color:var(--text);outline:none;resize:vertical}textarea{min-height:88px}textarea:focus,input:focus{border-color:#687cff;box-shadow:0 0 0 3px #687cff22}.hint{font-size:12px;color:var(--muted)}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#091525;color:#b8c8dd;padding:14px;border:1px solid #20344f;border-radius:12px;font:12px/1.55 ui-monospace,SFMono-Regular,Consolas,monospace}.actions{display:flex;gap:8px;flex-wrap:wrap}.nav{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 18px}.nav a{padding:8px 12px;border:1px solid #2a3c58;border-radius:999px;color:#afbdd0;font-size:13px;background:#0d192a}.footer{margin-top:26px;color:#71869f;text-align:center;font-size:12px}
@media(max-width:820px){body{padding:18px 13px 40px}.metric{grid-column:span 6}.wide,.side{grid-column:span 12}.hero{padding:23px}.topbar{align-items:flex-start}.brand-sub{display:none}}
@media(max-width:460px){.metric{grid-column:span 12}.metric-value{font-size:26px}.topbar{gap:8px}.brand-name{font-size:17px}.status-pill{padding:7px 10px}.hero-actions button{width:100%}.card{padding:18px}}
</style>
</head>
<body>
HTML
}

page_footer() {
    cat <<'HTML'
</body>
</html>
HTML
}
