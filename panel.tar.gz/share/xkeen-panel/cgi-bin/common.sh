#!/opt/bin/sh
PATH=/opt/sbin:/opt/bin:/opt/usr/sbin:/opt/usr/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH

TOKEN_FILE="/opt/etc/xkeen-panel/token"

html_escape() {
    sed \
      -e 's/&/\&amp;/g' \
      -e 's/</\&lt;/g' \
      -e 's/>/\&gt;/g' \
      -e 's/"/\&quot;/g'
}

url_decode() {
    VALUE="$(printf '%s' "$1" | sed 's/+/ /g; s/%/\\x/g')"
    printf '%b' "$VALUE"
}

get_field() {
    FIELD="$1"

    printf '%s' "$POST_DATA" |
    tr '&' '\n' |
    sed -n "s/^${FIELD}=//p" |
    head -n 1
}

read_post() {
    case "${CONTENT_LENGTH:-0}" in
        ''|*[!0-9]*) CONTENT_LENGTH=0 ;;
    esac

    POST_DATA="$(dd bs=1 count="$CONTENT_LENGTH" 2>/dev/null)"
}

check_token() {
    RECEIVED="$(url_decode "$(get_field token)")"
    EXPECTED="$(cat "$TOKEN_FILE" 2>/dev/null)"

    [ -n "$EXPECTED" ] && [ "$RECEIVED" = "$EXPECTED" ]
}

page_header() {
    TITLE="$1"

    printf 'Content-Type: text/html; charset=utf-8\r\n'
    printf 'Cache-Control: no-store\r\n'
    printf '\r\n'

    cat <<HTML
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>$TITLE</title>
<style>
body {
  max-width: 760px;
  margin: 24px auto;
  padding: 0 14px;
  font-family: Arial,sans-serif;
  background: #f2f4f7;
  color: #202124;
}
.card {
  background: white;
  padding: 20px;
  margin-bottom: 16px;
  border-radius: 14px;
  box-shadow: 0 3px 16px rgba(0,0,0,.08);
}
button {
  border: 0;
  border-radius: 8px;
  padding: 12px 15px;
  margin: 4px 3px;
  font-size: 15px;
  cursor: pointer;
}
.start { background:#16883f; color:white; }
.stop { background:#c73535; color:white; }
.restart,.update { background:#1769e0; color:white; }
.save { background:#5d3db7; color:white; }
textarea {
  box-sizing:border-box;
  width:100%;
  min-height:76px;
  padding:10px;
  border:1px solid #bbb;
  border-radius:8px;
}
pre {
  white-space:pre-wrap;
  overflow-wrap:anywhere;
  background:#eef1f4;
  padding:12px;
  border-radius:8px;
}
.ok { color:#16883f; font-weight:bold; }
.bad { color:#c73535; font-weight:bold; }
a { color:#1769e0; }
</style>
</head>
<body>
HTML
}

page_footer() {
    cat <<'HTML'
</body>
</html>
HTML
}
